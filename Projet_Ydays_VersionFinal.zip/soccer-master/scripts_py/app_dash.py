# Importation des modules nécessaires
import dash
import dash_core_components as dcc
import dash_html_components as html
import dash_bootstrap_components as dbc

# Mise en place de l'application Dash
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

# Définition des couleurs
colors = {
    'background': '#000000',  # Noir
    'text': '#FFFFFF'  # Blanc
}

# Fonction pour le rendu de la page d'accueil
def render_home_page():
    return html.Div([
        html.H1('Bienvenue sur notre Dashboard des championnats du big five Européen !', style={'color': colors['text'], 'margin-bottom': '80px'}),
        html.P("Vous trouverez des Dashboards actualisés à la saison actuelle ainsi que les précédentes saisons !", style={'color': colors['text']}),
        html.P("Vous pourrez faire des comparaisons intéressantes entre les championnats et entre les saisons !", style={'color': colors['text']}),
        html.P("Choisissez dans la navbar le championnat de votre choix ;)", style={'color': colors['text'], 'margin-top': '20px'})
    ], style={'textAlign': 'center', 'padding': '50px'})

# Mise en page de la navbar
navbar = dbc.NavbarSimple(
    children=[
        dbc.NavItem(dbc.NavLink("Accueil", href="/")),
        dbc.NavItem(dbc.NavLink("L1", href="/dashboard/L1")),
        dbc.NavItem(dbc.NavLink("Liga", href="/Liga")),  
        dbc.NavItem(dbc.NavLink("SerieA", href="/SerieA")),
        dbc.NavItem(dbc.NavLink("Bundes", href="/Bundes")),
        dbc.NavItem(dbc.NavLink("PL", href="/PL")),
    ],
    brand="Navigation",
    brand_href="#",
    color="dark",
    dark=True,
)

# Mise en page de l'application
app.layout = html.Div(style={'backgroundColor': colors['background'], 'height': '100vh'}, children=[
    # Barre de navigation
    navbar,
    # Composant dcc.Location pour suivre l'URL
    dcc.Location(id='url', refresh=False),
    # Contenu de la page d'accueil
    html.Div(id='page-content')
])

# Callback pour rendre la page d'accueil
@app.callback(
    dash.dependencies.Output('page-content', 'children'),
    [dash.dependencies.Input('url', 'pathname')]
)
def display_page(pathname):
    if pathname == '/':
        return render_home_page()
    else:
        return html.H1('404 - Page not found', style={'color': colors['text']})

# Point d'entrée de l'application
if __name__ == '__main__':
    app.run_server(debug=True)
