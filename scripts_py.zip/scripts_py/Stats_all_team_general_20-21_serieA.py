from bs4 import BeautifulSoup
import csv
from pymongo import MongoClient
import pandas as pd

html_content = """
<div id="statistics-team-table-summary" class="" data-fwsc="1"><div class="ml12-lg-2 ml12-m-3 ml12-s-4 ml12-xs-5 semi-attached-table"><table class="grid with-centered-columns hover" id="top-team-stats-summary-grid"><thead><tr><th class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs" data-default-sort-dir="asc" data-property="TeamName">Équipe</th> <th class="global sortable goal   " data-stat-name="goal">Buts</th><th class="global sortable shotsPerGame   " data-stat-name="shotsPerGame">Tirs pm</th><th class="global sortable yellowCard   " data-stat-name="yellowCard">Discipline</th><th class="global sortable possession   " data-stat-name="possession">Possession%</th><th class="global sortable passSuccess   " data-stat-name="passSuccess">PassesRéussies%</th><th class="global sortable aerialWonPerGame   " data-stat-name="aerialWonPerGame">AériensGagnés</th><th class="global sortable rating " data-property="Rating" data-stat-name="Rating">Note</th></tr></thead><tbody id="top-team-stats-summary-content" style=""><tr><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/87/Show/Italie-Juventus">1. Juventus</a></td> <td class="goal   ">77</td><td class="shotsPerGame   ">15.7</td><td class="aaa"><span class="yellow-card-box">76</span><span class="red-card-box">6</span></td><td class="possession   ">26.5</td><td class="passSuccess   ">88.3</td><td class="aerialWonPerGame   ">11.4</td><td class="  sorted "><span class="stat-value rating">6.85</span></td></tr><tr class="alt"><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/300/Show/Italie-Atalanta">2. Atalanta</a></td> <td class="goal   ">90</td><td class="shotsPerGame   ">16.3</td><td class="aaa"><span class="yellow-card-box">66</span><span class="red-card-box">3</span></td><td class="possession   ">29.6</td><td class="passSuccess   ">83.5</td><td class="aerialWonPerGame   ">16.8</td><td class="  sorted "><span class="stat-value rating">6.84</span></td></tr><tr><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/80/Show/Italie-AC-Milan">3. AC Milan</a></td> <td class="goal   ">74</td><td class="shotsPerGame   ">14.7</td><td class="aaa"><span class="yellow-card-box">80</span><span class="red-card-box">4</span></td><td class="possession   ">51.4</td><td class="passSuccess   ">84.0</td><td class="aerialWonPerGame   ">15.2</td><td class="  sorted "><span class="stat-value rating">6.82</span></td></tr><tr class="alt"><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/75/Show/Italie-Inter">4. Inter</a></td> <td class="goal   ">89</td><td class="shotsPerGame   ">14.5</td><td class="aaa"><span class="yellow-card-box">59</span><span class="red-card-box">2</span></td><td class="possession   ">52.0</td><td class="passSuccess   ">87.0</td><td class="aerialWonPerGame   ">11.8</td><td class="  sorted "><span class="stat-value rating">6.81</span></td></tr><tr><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/276/Show/Italie-Napoli">5. Napoli</a></td> <td class="goal   ">86</td><td class="shotsPerGame   ">17</td><td class="aaa"><span class="yellow-card-box">71</span><span class="red-card-box">3</span></td><td class="possession   ">54.1</td><td class="passSuccess   ">87.0</td><td class="aerialWonPerGame   ">11.1</td><td class="  sorted "><span class="stat-value rating">6.81</span></td></tr><tr class="alt"><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/84/Show/Italie-Roma">6. Roma</a></td> <td class="goal   ">68</td><td class="shotsPerGame   ">14.3</td><td class="aaa"><span class="yellow-card-box">84</span><span class="red-card-box">3</span></td><td class="possession   ">51.5</td><td class="passSuccess   ">84.5</td><td class="aerialWonPerGame   ">12.1</td><td class="  sorted "><span class="stat-value rating">6.71</span></td></tr><tr><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/2889/Show/Italie-Sassuolo">7. Sassuolo</a></td> <td class="goal   ">64</td><td class="shotsPerGame   ">13.9</td><td class="aaa"><span class="yellow-card-box">74</span><span class="red-card-box">4</span></td><td class="possession   ">31.3</td><td class="passSuccess   ">87.8</td><td class="aerialWonPerGame   ">10.9</td><td class="  sorted "><span class="stat-value rating">6.67</span></td></tr><tr class="alt"><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/271/Show/Italie-Sampdoria">8. Sampdoria</a></td> <td class="goal   ">52</td><td class="shotsPerGame   ">11.3</td><td class="aaa"><span class="yellow-card-box">81</span><span class="red-card-box">3</span></td><td class="possession   ">20.6</td><td class="passSuccess   ">78.5</td><td class="aerialWonPerGame   ">16.8</td><td class="  sorted "><span class="stat-value rating">6.63</span></td></tr><tr><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/77/Show/Italie-Lazio">9. Lazio</a></td> <td class="goal   ">61</td><td class="shotsPerGame   ">13.8</td><td class="aaa"><span class="yellow-card-box">100</span><span class="red-card-box">5</span></td><td class="possession   ">52.2</td><td class="passSuccess   ">83.8</td><td class="aerialWonPerGame   ">14.6</td><td class="  sorted "><span class="stat-value rating">6.62</span></td></tr><tr class="alt"><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/72/Show/Italie-Torino">10. Torino</a></td> <td class="goal   ">50</td><td class="shotsPerGame   ">12.2</td><td class="aaa"><span class="yellow-card-box">72</span><span class="red-card-box">4</span></td><td class="possession   ">23.5</td><td class="passSuccess   ">80.5</td><td class="aerialWonPerGame   ">16.1</td><td class="  sorted "><span class="stat-value rating">6.59</span></td></tr><tr><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/76/Show/Italie-Verona">11. Verona</a></td> <td class="goal   ">43</td><td class="shotsPerGame   ">10.6</td><td class="aaa"><span class="yellow-card-box">91</span><span class="red-card-box">1</span></td><td class="possession   ">49.6</td><td class="passSuccess   ">76.3</td><td class="aerialWonPerGame   ">20.6</td><td class="  sorted "><span class="stat-value rating">6.59</span></td></tr><tr class="alt"><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/78/Show/Italie-Cagliari">12. Cagliari</a></td> <td class="goal   ">43</td><td class="shotsPerGame   ">11.4</td><td class="aaa"><span class="yellow-card-box">73</span><span class="red-card-box">3</span></td><td class="possession   ">45.8</td><td class="passSuccess   ">79.8</td><td class="aerialWonPerGame   ">17.2</td><td class="  sorted "><span class="stat-value rating">6.58</span></td></tr><tr><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/71/Show/Italie-Bologna">13. Bologna</a></td> <td class="goal   ">51</td><td class="shotsPerGame   ">13.1</td><td class="aaa"><span class="yellow-card-box">78</span><span class="red-card-box">4</span></td><td class="possession   ">50.7</td><td class="passSuccess   ">81.5</td><td class="aerialWonPerGame   ">15.1</td><td class="  sorted "><span class="stat-value rating">6.56</span></td></tr><tr class="alt"><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/86/Show/Italie-Udinese">14. Udinese</a></td> <td class="goal   ">42</td><td class="shotsPerGame   ">10.9</td><td class="aaa"><span class="yellow-card-box">63</span><span class="red-card-box">2</span></td><td class="possession   ">47.2</td><td class="passSuccess   ">82.5</td><td class="aerialWonPerGame   ">13.1</td><td class="  sorted "><span class="stat-value rating">6.55</span></td></tr><tr><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/278/Show/Italie-Genoa">15. Genoa</a></td> <td class="goal   ">47</td><td class="shotsPerGame   ">9</td><td class="aaa"><span class="yellow-card-box">85</span><span class="red-card-box">2</span></td><td class="possession   ">18.0</td><td class="passSuccess   ">79.7</td><td class="aerialWonPerGame   ">13.7</td><td class="  sorted "><span class="stat-value rating">6.54</span></td></tr><tr class="alt"><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/73/Show/Italie-Fiorentina">16. Fiorentina</a></td> <td class="goal   ">47</td><td class="shotsPerGame   ">9.8</td><td class="aaa"><span class="yellow-card-box">86</span><span class="red-card-box">5</span></td><td class="possession   ">46.8</td><td class="passSuccess   ">81.0</td><td class="aerialWonPerGame   ">14.2</td><td class="  sorted "><span class="stat-value rating">6.52</span></td></tr><tr><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/1501/Show/Italie-Spezia">17. Spezia</a></td> <td class="goal   ">52</td><td class="shotsPerGame   ">10.2</td><td class="aaa"><span class="yellow-card-box">92</span><span class="red-card-box">5</span></td><td class="possession   ">30.5</td><td class="passSuccess   ">81.1</td><td class="aerialWonPerGame   ">14.4</td><td class="  sorted "><span class="stat-value rating">6.50</span></td></tr><tr class="alt"><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/24341/Show/Italie-Parma-Calcio-1913">18. Parma Calcio 1913</a></td> <td class="goal   ">39</td><td class="shotsPerGame   ">10.4</td><td class="aaa"><span class="yellow-card-box">91</span><span class="red-card-box">1</span></td><td class="possession   ">24.9</td><td class="passSuccess   ">82.5</td><td class="aerialWonPerGame   ">16.9</td><td class="  sorted "><span class="stat-value rating">6.49</span></td></tr><tr><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/779/Show/Italie-Crotone">19. Crotone</a></td> <td class="goal   ">45</td><td class="shotsPerGame   ">9.5</td><td class="aaa"><span class="yellow-card-box">85</span><span class="red-card-box">4</span></td><td class="possession   ">15.6</td><td class="passSuccess   ">80.4</td><td class="aerialWonPerGame   ">12.7</td><td class="  sorted "><span class="stat-value rating">6.43</span></td></tr><tr class="alt"><td class="col12-lg-2 col12-m-3 col12-s-4 col12-xs-5 grid-abs overflow-text"><a class="team-link" href="/Teams/1503/Show/Italie-Benevento">20. Benevento</a></td> <td class="goal   ">40</td><td class="shotsPerGame   ">11</td><td class="aaa"><span class="yellow-card-box">90</span><span class="red-card-box">5</span></td><td class="possession   ">35.5</td><td class="passSuccess   ">77.7</td><td class="aerialWonPerGame   ">13.4</td><td class="  sorted "><span class="stat-value rating">6.43</span></td></tr></tbody></table></div></div>
"""
soup = BeautifulSoup(html_content, "html.parser")

data = []
headers = ['Équipe', 'Buts', 'Tirs pm', 'Discipline', 'Possession%', 'PassesRéussies%', 'AériensGagnés', 'Note']

table_body = soup.find("tbody", {"id": "top-team-stats-summary-content"})
rows = table_body.find_all("tr")

with open('football_stats_modified_20-21.csv', mode='w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    writer.writerow(['Équipe', 'Buts', 'Tirs pm', 'Discipline', 'Possession%', 'PassesRéussies%', 'AériensGagnés', 'Note'])

    for row in rows:
        cells = row.find_all("td")
        team_name = cells[0].text.strip().split(". ")[1]
        goals = cells[1].text.strip()
        shots_per_game = cells[2].text.strip()
        discipline = cells[3].text.strip()
        possession = cells[4].text.strip()
        passes_success = cells[5].text.strip()
        aerials_won = cells[6].text.strip()
        rating = cells[7].text.strip()
        writer.writerow([team_name, goals, shots_per_game, discipline, possession, passes_success, aerials_won, rating])

print("Les données ont été enregistrées dans football_stats_modified_20-21.csv avec succès !")

# Lire le fichier CSV dans un DataFrame
df = pd.read_csv("football_stats_modified_20-21.csv")

# Supprimer les colonnes "Note" et "Discipline"
df.drop(columns=["Note", "Discipline"], inplace=True)

# Ajouter une colonne "Journée" avec la valeur "26"
df.insert(0, "Journée", 38)

# Supprimer la colonne "Position" si elle existe déjà
if "Position" in df.columns:
    df.drop(columns=["Position"], inplace=True)

# Insérer une nouvelle colonne "Position" à l'index 1 (après la colonne "Journée")
df.insert(1, "Position", range(1, len(df) + 1))

# Convertir les types des colonnes "Journée" et "Buts"
df['Journée'] = df['Journée'].astype(int)
df['Buts'] = df['Buts'].astype(int)

# Enregistrer le DataFrame dans un fichier CSV (avec les modifications)
df.to_csv("football_stats_modified_20-21.csv", index=False)

print("Les données ont été extraites et enregistrées dans football_stats_modified_20-21.csv.")

# Connexion à la base de données MongoDB
client = MongoClient('mongodb://127.0.0.1:27017/?directConnection=true&serverSelectionTimeoutMS=2000&appName=mongosh+1.6.1')
db = client['SoccerStats']
collection_name = 'Stats_All_Team_General_20-21_serieA'

# Supprimer la collection si elle existe
if collection_name in db.list_collection_names():
    db.drop_collection(collection_name)
    print("La collection existe. Elle a été supprimée.")

# Recréer la collection
collection = db[collection_name]


# Convertir le DataFrame en dictionnaire pour l'insertion dans MongoDB
data_dict = df.to_dict(orient='records')

# Insérer les données dans la collection MongoDB
collection.insert_many(data_dict)

print("Les données ont été insérées dans la collection MongoDB avec succès.")